export function getNeighbors({ row, col }) {
  const deltas = [
    [-1, 0],
    [1, 0],
    [0, -1],
    [0, 1],
  ];

  return deltas
    .map(([dr, dc]) => ({ row: row + dr, col: col + dc }))
    .filter(({ row, col }) => row >= 0 && row < 20 && col >= 0 && col < 50);
}
