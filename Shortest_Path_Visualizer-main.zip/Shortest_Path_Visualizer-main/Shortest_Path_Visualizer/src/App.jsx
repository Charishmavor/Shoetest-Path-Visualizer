import React, { useRef, useState } from "react";
import Grid from "./components/Grid";

function App() {
  const gridRef = useRef();
  const [algorithm, setAlgorithm] = useState("");
  const [speed, setSpeed] = useState(20); // Default: Medium speed

  const handleVisualize = () => {
    if (algorithm) {
      gridRef.current.visualizeAlgorithm(algorithm);
    }
  };

  const handleClearPath = () => {
    gridRef.current.clearPath();
  };

  const handleClearWalls = () => {
    gridRef.current.clearWalls();
  };

  const handleClearGrid = () => {
    gridRef.current.clearGrid();
  };

  const handleMaze = () => {
    gridRef.current.generateMaze();
  };

  return (
    <div className="min-h-screen bg-gray-100 text-center px-2 py-4">
      {/* Heading */}
      <h1 className="text-4xl font-bold text-purple-800 mb-7">
        ⚡ Pathfinding Visualizer
      </h1>

      {/* Controls Section */}
      <div className="flex flex-wrap justify-center gap-8 mb-5">
        {/* Algorithm selection */}
        <div className="flex items-center gap-2">
          <label className="font-semibold">Algorithm:</label>
          <select
            value={algorithm}
            onChange={(e) => setAlgorithm(e.target.value)}
            className="px-3 py-1 rounded border border-gray-300"
          >
            <option value="" disabled>
              Select
            </option>
            <option value="dijkstra">Dijkstra's Algorithm</option>
            <option value="bfs">Breadth First Search (BFS)</option>
            <option value="dfs">Depth First Search (DFS)</option>
            <option value="astar">A* Search Algorithm</option>
          </select>
        </div>

        {/* Speed selection */}
        <div className="flex items-center gap-2">
          <label className="font-semibold">Speed:</label>
          <select
            value={speed}
            onChange={(e) => setSpeed(Number(e.target.value))}
            className="px-3 py-1 rounded border border-gray-300"
          >
            <option value={50}>Slow</option>
            <option value={20}>Medium</option>
            <option value={5}>Fast</option>
          </select>
        </div>

        {/* Action Buttons */}
        <button
          onClick={handleVisualize}
          className={`${
            !algorithm
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-green-500 hover:bg-green-600"
          } text-white px-4 py-2 rounded`}
          disabled={!algorithm}
        >
          ▶️ Visualize
        </button>

        <button
          onClick={handleClearPath}
          className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded"
        >
          🚫 Clear Path
        </button>

        <button
          onClick={handleClearWalls}
          className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded"
        >
          🧱 Clear Walls
        </button>

        <button
          onClick={handleClearGrid}
          className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded"
        >
          🧹 Clear Grid
        </button>

        <button
          onClick={handleMaze}
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
        >
          🧩 Generate Maze
        </button>
      </div>

      {/* Legend */}
      <div className="flex justify-center flex-wrap gap-8 text-sm mb-6">
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 bg-green-500 rounded-sm"></div> Start Node
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 bg-red-500 rounded-sm"></div> Target Node
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 bg-black rounded-sm"></div> Wall Node
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 bg-blue-500 rounded-sm"></div> Visited Node
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 bg-orange-400 rounded-sm"></div> Shortest Path
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 bg-purple-400 rounded-sm"></div> Weighted Node
        </div>
      </div>

      {/* Grid */}
      <div className="mt-6">
        <Grid ref={gridRef} speed={speed} />
      </div>

      <p className="text-sm text-gray-600 mt-4">
        💡 Tip: Drag the{" "}
        <span className="text-green-500 font-semibold">Start</span> and{" "}
        <span className="text-red-500 font-semibold">End</span> nodes to
        reposition them. Click on the grid to place or remove{" "}
        <span className="text-black font-semibold">Walls</span>. To add or
        remove <span className="text-purple-500 font-semibold">Weighted</span>{" "}
        nodes, hold the <span className="font-semibold">"W"</span> key while
        clicking.
      </p>
    </div>
  );
}

export default App;
