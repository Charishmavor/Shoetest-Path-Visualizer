import React, {
  useEffect,
  useRef,
  useState,
  useImperativeHandle,
  forwardRef,
} from "react";
import { bfs } from "../algorithms/bfs";
import { dfs } from "../algorithms/dfs";
import { dijkstra } from "../algorithms/dijkstra";
import { generateMaze } from "../algorithms/maze";
import { astar } from "../algorithms/astar";

const numRows = 20;
const numCols = 50;

const Grid = forwardRef((props, ref) => {
  const [grid, setGrid] = useState([]);
  const [walls, setWalls] = useState(new Set());
  const [weights, setWeights] = useState(new Map());
  const [weightMode, setWeightMode] = useState(false);
  const [start, setStart] = useState({ row: 5, col: 5 });
  const [end, setEnd] = useState({ row: 10, col: 35 });
  const [movingNode, setMovingNode] = useState(null);

  const generateEmptyGrid = () => {
    const rows = [];
    for (let row = 0; row < numRows; row++) {
      const currentRow = [];
      for (let col = 0; col < numCols; col++) {
        currentRow.push({ row, col });
      }
      rows.push(currentRow);
    }
    return rows;
  };

  useEffect(() => {
    setGrid(generateEmptyGrid());
  }, []);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "w" || e.key === "W") setWeightMode(true);
    };
    const handleKeyUp = (e) => {
      if (e.key === "w" || e.key === "W") setWeightMode(false);
    };
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, []);

  useImperativeHandle(ref, () => ({
    visualizeAlgorithm(type) {
      let visited = [];
      let path = [];

      if (type === "bfs") [visited, path] = bfs(start, end, walls);
      else if (type === "dfs") [visited, path] = dfs(start, end, walls);
      else if (type === "dijkstra")
        [visited, path] = dijkstra(start, end, walls, weights);
      else if (type === "astar")
        [visited, path] = astar(start, end, walls, weights);

      if (path.length === 0) {
        alert("🚫 No path found between Start and End!");
      } else {
        const lastNode = path[path.length - 1];
        const isValidPath =
          lastNode.row === end.row && lastNode.col === end.col;

        animateTraversal(visited, path, () => {
          if (isValidPath) {
            let totalCost = 0;
            for (const node of path) {
              const key = `${node.row}-${node.col}`;
              totalCost += weights.has(key) ? weights.get(key) : 1;
            }
            alert(`✅ Steps: ${path.length}, Total Cost: ${totalCost}`);
          } else {
            alert("🚫 No path found between Start and End!");
          }
        });
      }
    },

    clearGrid() {
      setGrid(generateEmptyGrid());
      setWalls(new Set());
      setWeights(new Map());

      document.querySelectorAll(".node").forEach((node) => {
        const id = node.id;
        if (
          id !== `${start.row}-${start.col}` &&
          id !== `${end.row}-${end.col}`
        ) {
          node.className = "node w-5 h-5 border border-gray-300 bg-white";
        }
      });
    },

    clearWalls() {
      document.querySelectorAll(".node").forEach((node) => {
        node.classList.remove("wall");
      });
      setWalls(new Set());
    },

    clearPath() {
      document.querySelectorAll(".node").forEach((node) => {
        const id = node.id;
        if (
          id !== `${start.row}-${start.col}` &&
          id !== `${end.row}-${end.col}`
        ) {
          node.classList.remove("visited", "path");
        }
      });
    },

    generateMaze() {
      const mazeWalls = generateMaze(
        numRows,
        numCols,
        `${start.row}-${start.col}`,
        `${end.row}-${end.col}`
      );
      setWalls(mazeWalls);
      setGrid((prev) => [...prev]);
    },
  }));

  const animateTraversal = (visited, path, callback) => {
    const visitDelay = 20;
    const pathDelay = 30;

    visited.forEach((node, i) => {
      setTimeout(() => {
        const el = document.getElementById(`${node.row}-${node.col}`);
        const isStart = node.row === start.row && node.col === start.col;
        const isEnd = node.row === end.row && node.col === end.col;
        const isWeighted = weights.has(`${node.row}-${node.col}`);
        if (el && !isStart && !isEnd) {
          if (!isWeighted) {
            el.classList.add("visited");
          } else {
            el.classList.add("visited", "weight");
          }
        }
      }, visitDelay * i);
    });

    const totalVisitedTime = visitDelay * visited.length;

    setTimeout(() => {
      path.forEach((node, i) => {
        setTimeout(() => {
          const el = document.getElementById(`${node.row}-${node.col}`);
          const isStart = node.row === start.row && node.col === start.col;
          const isEnd = node.row === end.row && node.col === end.col;
          const isWeighted = weights.has(`${node.row}-${node.col}`);
          if (el && !isStart && !isEnd) {
            if (!isWeighted) {
              el.classList.add("path");
            } else {
              el.classList.add("path", "weight");
            }
          }
          if (i === path.length - 1 && callback) {
            callback();
          }
        }, totalVisitedTime + pathDelay * i);
      });
    });
  };

  const handleMouseDown = (row, col) => {
    const key = `${row}-${col}`;
    if (key === `${start.row}-${start.col}`) setMovingNode("start");
    else if (key === `${end.row}-${end.col}`) setMovingNode("end");
    else if (weightMode) {
      const newWeights = new Map(weights);
      if (newWeights.has(key)) {
        newWeights.delete(key);
        document.getElementById(key)?.classList.remove("weight");
      } else {
        newWeights.set(key, 5);
        document.getElementById(key)?.classList.add("weight");
      }
      setWeights(newWeights);
    } else {
      const newWalls = new Set(walls);
      if (newWalls.has(key)) newWalls.delete(key);
      else newWalls.add(key);
      setWalls(newWalls);
    }
  };

  const handleMouseEnter = (row, col) => {
    if (movingNode === "start") setStart({ row, col });
    else if (movingNode === "end") setEnd({ row, col });
  };

  const handleMouseUp = () => {
    setMovingNode(null);
  };

  return (
    <div
      className="grid gap-1"
      style={{
        gridTemplateColumns: `repeat(${numCols}, 20px)`,
        justifyContent: "center",
        userSelect: "none",
      }}
      onMouseUp={handleMouseUp}
    >
      {grid.map((row) =>
        row.map((node) => {
          const key = `${node.row}-${node.col}`;
          const isStart = node.row === start.row && node.col === start.col;
          const isEnd = node.row === end.row && node.col === end.col;
          const isWall = walls.has(key);
          const isWeighted = weights.has(key);

          let bg = "bg-white";
          if (isWall) bg = "bg-black";
          else if (isWeighted) bg = "bg-purple-500";
          else if (isStart) bg = "bg-green-500";
          else if (isEnd) bg = "bg-red-500";

          return (
            <div
              key={key}
              id={key}
              onMouseDown={() => handleMouseDown(node.row, node.col)}
              onMouseEnter={() => handleMouseEnter(node.row, node.col)}
              className={`node w-5 h-5 border border-gray-300 ${bg} transition-all duration-100`}
            />
          );
        })
      )}
    </div>
  );
});

export default Grid;
