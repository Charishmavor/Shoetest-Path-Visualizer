import { getNeighbors } from "../utils/getNeighbors.js";

export function dijkstra(start, end, walls, weights = new Map()) {
  const visitedOrder = [];
  const distances = {};
  const prev = {};
  const visited = new Set();

  for (let r = 0; r < 20; r++) {
    for (let c = 0; c < 50; c++) {
      distances[`${r}-${c}`] = Infinity;
    }
  }

  const startKey = `${start.row}-${start.col}`;
  const endKey = `${end.row}-${end.col}`;
  distances[startKey] = 0;

  while (true) {
    let minDist = Infinity;
    let minNode = null;

    for (let r = 0; r < 20; r++) {
      for (let c = 0; c < 50; c++) {
        const key = `${r}-${c}`;
        if (!visited.has(key) && distances[key] < minDist) {
          minDist = distances[key];
          minNode = { row: r, col: c };
        }
      }
    }

    if (!minNode) break;

    const key = `${minNode.row}-${minNode.col}`;
    if (walls.has(key)) {
      visited.add(key);
      continue;
    }

    visited.add(key);
    visitedOrder.push(minNode);

    if (key === endKey) break;

    for (const neighbor of getNeighbors(minNode)) {
      const nKey = `${neighbor.row}-${neighbor.col}`;
      if (visited.has(nKey) || walls.has(nKey)) continue;

      const weight = weights.get(nKey) ?? 1;
      const alt = distances[key] + weight;

      if (alt < distances[nKey]) {
        distances[nKey] = alt;
        prev[nKey] = key;
      }
    }
  }

  const path = [];
  let currentKey = endKey;

  while (prev[currentKey]) {
    const [row, col] = currentKey.split("-").map(Number);
    path.unshift({ row, col });
    currentKey = prev[currentKey];
  }

  if (path.length > 0) path.unshift(start);

  return [visitedOrder, path];
}
