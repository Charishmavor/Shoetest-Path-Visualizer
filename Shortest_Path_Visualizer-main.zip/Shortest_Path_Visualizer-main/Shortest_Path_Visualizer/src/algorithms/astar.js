import { getNeighbors } from "../utils/getNeighbors";

function heuristic(a, b) {
  return Math.abs(a.row - b.row) + Math.abs(a.col - b.col);
}

export function astar(start, end, walls, weights = new Map()) {
  const openSet = new Set([`${start.row}-${start.col}`]);
  const cameFrom = {};
  const gScore = { [`${start.row}-${start.col}`]: 0 };
  const fScore = { [`${start.row}-${start.col}`]: heuristic(start, end) };
  const visitedNodes = [];

  while (openSet.size > 0) {
    let currentKey = null;
    let minF = Infinity;

    for (let key of openSet) {
      if (fScore[key] < minF) {
        minF = fScore[key];
        currentKey = key;
      }
    }

    openSet.delete(currentKey);

    const [row, col] = currentKey.split("-").map(Number);
    const current = { row, col };

    if (walls.has(currentKey)) continue;
    visitedNodes.push(current);

    if (currentKey === `${end.row}-${end.col}`) break;

    for (const neighbor of getNeighbors(current)) {
      const nKey = `${neighbor.row}-${neighbor.col}`;
      if (walls.has(nKey)) continue;

      const weight = weights.get(nKey) ?? 1;
      const tentativeG = (gScore[currentKey] ?? Infinity) + weight;

      if (tentativeG < (gScore[nKey] ?? Infinity)) {
        cameFrom[nKey] = currentKey;
        gScore[nKey] = tentativeG;
        fScore[nKey] = tentativeG + heuristic(neighbor, end);
        openSet.add(nKey);
      }
    }
  }

  const path = [];
  let current = `${end.row}-${end.col}`;

  if (!cameFrom[current]) return [visitedNodes, []];

  while (cameFrom[current]) {
    const [row, col] = current.split("-").map(Number);
    path.unshift({ row, col });
    current = cameFrom[current];
  }

  path.unshift(start);

  return [visitedNodes, path];
}
