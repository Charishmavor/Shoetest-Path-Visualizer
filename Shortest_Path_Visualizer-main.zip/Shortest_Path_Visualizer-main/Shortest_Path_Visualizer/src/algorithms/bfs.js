import { getNeighbors } from "../utils/getNeighbors";

export function bfs(start, end, walls) {
  const queue = [[start]];
  const visited = new Set();
  const visitedOrder = [];

  while (queue.length) {
    const path = queue.shift();
    const node = path[path.length - 1];
    const key = `${node.row}-${node.col}`;

    if (visited.has(key) || walls.has(key)) continue;

    visited.add(key);
    visitedOrder.push(node);

    if (node.row === end.row && node.col === end.col) return [visitedOrder, path];

    for (const neighbor of getNeighbors(node)) {
      queue.push([...path, neighbor]);
    }
  }

  return [visitedOrder, []];
}
