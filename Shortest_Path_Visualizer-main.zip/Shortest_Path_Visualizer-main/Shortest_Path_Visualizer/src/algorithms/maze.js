export function generateMaze(rows, cols, startKey, endKey) {
  const walls = new Set();
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const key = `${row}-${col}`;
      if (key === startKey || key === endKey || Math.random() > 0.1) continue;
      walls.add(key);
    }
  }
  return walls;
}
