import { getNeighbors } from "../utils/getNeighbors";

export function dfs(start, end, walls) {
  const stack = [[start]];
  const visited = new Set();
  const visitedOrder = [];

  while (stack.length) {
    const path = stack.pop();
    const node = path[path.length - 1];
    const key = `${node.row}-${node.col}`;

    if (visited.has(key) || walls.has(key)) continue;

    visited.add(key);
    visitedOrder.push(node);

    if (node.row === end.row && node.col === end.col) return [visitedOrder, path];

    for (const neighbor of getNeighbors(node)) {
      stack.push([...path, neighbor]);
    }
  }

  return [visitedOrder, []];
}
